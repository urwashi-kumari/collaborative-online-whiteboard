function ExploreContainer(){
    return(
        <div className="w-screen h-screen bg-[#D4B8EA] flex items-center justify-center">Under Maintainance ,<br />Update Soon...</div>
    )
}

export default ExploreContainer